
import React, { Component, useState } from 'react';
import SortableTree from 'react-sortable-tree';
import 'react-sortable-tree/style.css'; 
import './DragFolder.css';

const data = [
    { title: 'Chicken', children: [{ title: 'Egg' }] },
    { title: 'Fish', children: [{ title: 'fingerline' }] },
    { title: 'Mutton', children: [{ title: 'half' }] },
    { title: 'Beef', children: [{ title: 'full' }] },
    { title: 'Egg', children: [{ title: 'dozen' }] },
]



const DragFolder = () => {
    const [treeData,setTreeData] = useState(data)
    // const renderButton = (title) => {
    //   return  <button >Your button</button> 
    // }
    return (
        <div style={{ height: 900 }}>
        <SortableTree
          treeData={treeData}
          onChange={treeData => setTreeData(treeData)}
        //   generateNodeProps={({ node, path }) => ({
        //     title: (
        //       <a href={node.url}>
        //       {node.title}
        //       <span className='title-button'> <a > {renderButton(node.title)}</a></span>
        //     </a>
                
        //     ),
        // })}
        generateNodeProps={extendedNode => ({
          title: (
              <p href={extendedNode.node.url}>{extendedNode.node.title}</p>
          ),
          buttons:  [<a ><button >X</button> <button> $ </button> <button> # </button></a> ] ,
         
      })}
        />
      </div>
    );
};

export default DragFolder;