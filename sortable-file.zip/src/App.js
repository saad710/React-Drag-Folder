import logo from './logo.svg';
import './App.css';
import DragFolder from './DragFolder';
import React from 'react';

function App() {
  return (
    <div className="App">
      <DragFolder/>
    </div>
  );
}

export default App;
